/*
  The program prints all triplets (x, y, z) of intgers
  such that
         1 <= x <= y <= z <= N
              and
          x*x + y*y = z*z
*/

public class E7{

  public static void main(String[] args) {
    int n = Integer.parseInt(args[0]);
    // your code here!
    System.out.println("And that was all!");
  }

}
