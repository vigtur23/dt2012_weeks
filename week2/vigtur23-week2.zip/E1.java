/*

  This program does not compile!
  Correct it so that it compiles and does
  what you think the programmer tried to achieve.

*/
public class E1{

  public static void main(String[] args) {
    int x = Integer.parseInt(args[0]);
    int y = Integer.parseInt(args[1]);

    if (x == y){
      System.out.println("x is equal to y");
    }

  }

}
