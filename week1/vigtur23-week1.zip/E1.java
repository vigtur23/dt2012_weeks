/*
This program is compiled using
   javac E1.java

and is ran using
   java E1

Add code so that the program  prints one more line with the message
   Welcome to the programming course!
after the
   Hello, world!
message.

*/
public class E1{

  public static void main(String[] args) {
    System.out.println("Hello, world!");
    System.out.println("Welcome to the programming course!");
  }

}
